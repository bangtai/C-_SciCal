#ifndef __POINT2D_H
#define __POINT2D_H

#include <iostream>

namespace ams562 {

class Point2D {
public:
    //
    // Constructors
    Point2D();                      // implementation needed
    Point2D(const Point2D &p);      // implementation needed
    Point2D(int x, int y);          // implementation needed

    //
    // Methods for accessing
    // implementation needed

    //
    // orientation
    // implementation needed
    int orientation(const Point2D &a, const Point2D &b) const;

    //
    // backend swapping
    // implementation needed
    void swap(Point2D &other);

    //
    // Operator =
    // implementation needed
    Point2D & operator=(const Point2D &p);

private:
    int x_, y_;
    friend std ::ostream & operator<<(std::ostream &, const Point2D &);
    friend std ::istream & operator>>(std::istream &, Point2D &);
};

//
// ostream::operator<<
inline std::ostream & operator<<(std::ostream &out, const Point2D &p) {
    out << p.x_ << ' ' << p.y_ << ' ';
    return out;
}

//
// istream::operator>>
// implementation needed
inline std::istream & operator>>(std::istream &in, Point2D &p);

//
// distance square
// implementation needed
inline int dist_sq(const Point2D &p1, const Point2D &p2);

}

#endif
