#include "GrahamScan.h"
#include <algorithm>

namespace ams562 {

void GrahamScan::apply(std::vector<Point2D> &pc, std::vector<Point2D> &ch) const {

    //
    // First find the lowest point by using std::max_element
    // if there are ties, pick the most left one

    //
    // Then, swap that point with the first element in pc

    //
    // Next step is to sort the 2nd point to the last point in pc
    // by polar angle with the first point in pc
    // Note that the first point in pc is the lowest point in the
    // point cloud. std::sort

    //
    // Push back the first and second points to the back
    // of ch, push_back of ch should be used

    //
    // Bonus, I do the cur for you

    auto cur = pc.begin()+2;
    while (cur != pc.end()) {
        //
        // Get the last 2 points in ch by using iterators
        // note that you can start with ch.end(), be aware
        // of the position of ch.end()

        //
        // Compute the orientation information of ch's last1
        // last2 and cur

        //
        // if cur is to left of last1_last2
        // then push cur to ch

        //
        // else if cur is collinear and cur lies futher
        // replace the last point of ch by cur

        //
        // else, pop the last point back from ch
        // and keep ch unchanged
    }
}

}
