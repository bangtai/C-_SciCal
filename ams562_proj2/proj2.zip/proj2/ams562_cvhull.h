#ifndef __AMS562_CVHULL_H
#define __AMS562_CVHULL_H

#include "cvhull/GrahamScan.h"
#include "cvhull/_Interface.h"

#endif
